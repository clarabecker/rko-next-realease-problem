/*** Parser for the AP instances. 
***/	 

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <time.h>
#include <math.h>

#include <sys/timeb.h>

//----------------------------------------------------------------------------------
//Variaveis globais

//dados do problema
float	 **coord, **demand;
float   **distance;			
int		 qtdNodes;

void	Exec( char name[] );
void	Distances();
void    Desaloca();
void	Write( char name[] );

//----------------------------------------------------------------------------------

void  Exec( char name[] ){  
	int   i, j, id;
	FILE  *input;
	char  ligne[256];
		
	input = fopen(name, "r");
	if ( input )
	{
	
		fscanf(input, "%d", &qtdNodes);

		coord = (float **) malloc(sizeof(float*) * qtdNodes);	  
		demand = (float **) malloc(sizeof(float*) * qtdNodes);	  

		for( i=0; i < qtdNodes; i++)
		{			      
			coord[i] = (float *) malloc(sizeof(float) * 2);	 		
			demand[i] = (float *) malloc(sizeof(float) * qtdNodes);	 		
		}//end_for_j

		for( i=0; i < qtdNodes; i++ )
		{
			fscanf(input, "%f %f", &coord[i][0],  &coord[i][1]);
		}//end_for_i

		for( i=0; i < qtdNodes; i++ )
		{
			for( j=0; j < qtdNodes; j++ )
			{
				fscanf(input, "%f", &demand[i][j]);		
			}//end_for
		}//end_for_i
	}//end_exec
	fclose(input);
	
	Distances();
	Write(name);

}//end_run


//----------------------------------------------------------------------------------

void Write( char name[] )
{
	for (int p = 0; p<3; p++)
	{
		int nHubs; 
		if (p==0) nHubs = 3;
		if (p==1) nHubs = 5;
		if (p==2) nHubs = 8;

		for (int a=0; a<3; a++)
		{
			float alfa;

			if (a==0) alfa = 0.20;
			if (a==1) alfa = 0.50;
			if (a==2) alfa = 0.80;

			int		i, j;

			char    nameOut[256]="";
			FILE    * out;
			int		position;

			char 	string[20]="";
			
			position = (int)strlen(name) - 4;
			strncpy(nameOut, name, position);

			if (p==0 && a==0) strcat(nameOut, "_3_02");
			if (p==0 && a==1) strcat(nameOut, "_3_05");
			if (p==0 && a==2) strcat(nameOut, "_3_08");
			if (p==1 && a==0) strcat(nameOut, "_5_02");
			if (p==1 && a==1) strcat(nameOut, "_5_05");
			if (p==1 && a==2) strcat(nameOut, "_5_08");
			if (p==2 && a==0) strcat(nameOut, "_8_02");
			if (p==2 && a==1) strcat(nameOut, "_8_05");
			if (p==2 && a==2) strcat(nameOut, "_8_08");
			
			strcat(nameOut, ".txt");
			out = fopen(nameOut, "w+");
			
			if ( out )
			{
				// fprintf(out, "TREE_HUB_INSTANCE\n");
				fprintf(out, "%d \t %d \t %.1f", qtdNodes, nHubs, alfa);
				j = (qtdNodes*(qtdNodes-1))/2;
				// fprintf(out, "NB_ARCS\t%d\n", j);
				// fprintf(out, "LIST_OF_ARCS\t DEMAND\t COST\n");

				for( i = 0; i < qtdNodes; i++)
				{
					for( j = 0; j < qtdNodes; j++)
					{	
						if( distance[i][j] > 0 )
						{
							fprintf(out, "\n%d\t %d\t %f\t %.6f", i, j, demand[i][j], distance[i][j]);
						}//end_if
						else
						{
							fprintf(out, "\n%d\t %d\t %f\t %.0f", i, j, demand[i][j], ceil(distance[i][j]));
						}//end_else

					}//end_for			
				}//end_for

				// fprintf(out, "END\n");
				// fprintf(out, "< AP's instances converted by Andrea Santos, 2011 >\n");		
			}//end_if		

			fclose(out);
		}
	}
}//end_calClusters

//----------------------------------------------------------------------------------

void Distances()
{
	 int	 i, j;	 
	 float  fator;
	 
	 distance = (float **) malloc(sizeof(float*) * qtdNodes);	   	   	   
	 for( i=0; i<qtdNodes; i++)
	 {			    
		 distance[i] = (float *) malloc(sizeof(float) * qtdNodes);	 	  
	 }//end_for_i

	
	 for( i=0; i < qtdNodes; i++ )
	 {  
		 for( j=0; j<=i; j++ )	
		 {				
			 if( i==j )
			 {
				 distance[i][j] = 0;
			 }//end_if
			 else
			 {
				//  x = coord[i][0] - coord[j][0];
				//  y = coord[i][1] - coord[j][1];
				//  fator = sqrt( (x*x) + (y*y) );
				 fator = sqrt(pow(coord[i][0] - coord[j][0],2) + pow(coord[i][1] - coord[j][1],2));
				 distance[i][j] = fator;				
				 distance[j][i] = fator;				
			 }//end_else
		 }//end_for_j
	 }//end_for_i
}//end_calcDist


//----------------------------------------------------------------------------------
//desaloca estruturas de dados

void Desaloca()
{
  int i;
  
  for( i=0; i<qtdNodes; i++)
  {    
     free(coord[i]);	 
	 free(distance[i]);	
  }free(coord);   
  free(distance);

  free(demand);

}//fim_desaloca

//----------------------------------------------------------------------------------

//Programa principal 
//Par�metros de entrada:
// 1. file name

int main(int argc, char** argv)
{
  float alpha;

  if( argc < 1 )
  {	
    printf("Faltam parametros\n");
  }//end_if
  else
  {		
	Exec( argv[1] );	
	Desaloca();					//desaloca estruturas de dados
  }//end_else

  return(0);

}//end_main

//----------------------------------------------------------------------------------